package com.example.sensorapp.domain.model

enum class Algorithm {
    EWMA_FILTER,
    SENSOR_FUSION
}